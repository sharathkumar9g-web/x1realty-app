/* Business Desk voice controls */
(() => {
  const form = document.querySelector('#voice-command');
  const input = form.elements.command;
  const runButton = document.querySelector('#voice-run');
  const listenButton = document.querySelector('#voice-listen');
  const stopButton = document.querySelector('#voice-stop');
  const readAloud = document.querySelector('#voice-read');
  const notice = document.querySelector('#voice-status');
  const response = document.querySelector('#voice-response');
  const actions = document.querySelector('#voice-actions');
  const speech = window.speechSynthesis;
  const Recognition = window.SpeechRecognition || window.webkitSpeechRecognition;
  let recognition = null;
  let listening = false;
  let running = false;

  function reply(text) {
    response.textContent = text;
    if (!readAloud.checked || !speech || typeof SpeechSynthesisUtterance !== 'function') return;
    speech.cancel();
    const utterance = new SpeechSynthesisUtterance(text);
    speech.speak(utterance);
  }

  function launch(label, url) {
    actions.append(externalLink(label, url));
  }

  function openRequestedPage(label, url) {
    let tab;
    try { tab = window.open('about:blank', '_blank'); } catch { /* A browser policy can block a popup. */ }
    if (!tab) {
      launch(label, url);
      return false;
    }
    tab.opener = null;
    tab.location.replace(String(url));
    return true;
  }

  function post(path, values) {
    return request(path, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(values),
    });
  }

  async function findCustomer(name, eligible, missing) {
    const records = await request('/api/records');
    const match = records.find(item => item.name.localeCompare(name.trim(), undefined, { sensitivity: 'accent' }) === 0 && eligible(item));
    if (!match) throw new Error(missing);
    return match;
  }

  function searchYouTube(query) {
    const url = new URL('https://www.youtube.com/results');
    url.searchParams.set('search_query', query);
    if (openRequestedPage('Open YouTube results', url)) return 'I opened YouTube search for ' + query + '.';
    return 'YouTube search is ready for ' + query + '. Open the results and select a video.';
  }

  function parseDate(day, hour, minute, meridiem) {
    if (day === 'tomorrow' || day === 'today') {
      const parts = new Intl.DateTimeFormat('en-CA', {
        timeZone: 'Asia/Kolkata', year: 'numeric', month: '2-digit', day: '2-digit',
      }).formatToParts(new Date());
      const value = key => Number(parts.find(part => part.type === key).value);
      const at = new Date(Date.UTC(value('year'), value('month') - 1, value('day') + (day === 'tomorrow' ? 1 : 0)));
      day = at.toISOString().slice(0, 10);
    }
    let hours = Number(hour);
    if (meridiem) {
      if (hours < 1 || hours > 12) throw new Error('Use an hour from 1 to 12 with AM or PM.');
      hours = hours % 12 + (meridiem === 'pm' ? 12 : 0);
    }
    const minutes = Number(minute || 0);
    if (hours > 23 || minutes > 59) throw new Error('Enter a valid follow-up time.');
    const date = new Date(day + 'T' + String(hours).padStart(2, '0') + ':' + String(minutes).padStart(2, '0') + ':00+05:30');
    const istDate = Number.isFinite(+date)
      ? new Date(date.getTime() + 330 * 60000).toISOString().slice(0, 10)
      : '';
    if (istDate !== day) throw new Error('Enter a valid date.');
    if (+date <= Date.now()) throw new Error('Choose a follow-up time in the future.');
    return date.toISOString();
  }

  async function execute(text) {
    const command = text.replace(/^(?:hey\s+)?jarvis[\s,]+/i, '').replace(/[.!?]$/, '').trim();
    const lower = command.toLowerCase();
    if (/^(?:open|show) (?:me )?(?:youtube|you tube)$/.test(lower)) {
      if (openRequestedPage('Open YouTube', 'https://www.youtube.com/')) return 'I opened YouTube.';
      return 'YouTube is ready to open.';
    }
    if (/^(?:open|show) (?:me )?(?:gmail|g-mail)$/.test(lower)) {
      openRequestedPage('Open Gmail', 'https://mail.google.com/');
      return 'Gmail is ready to open.';
    }
    const directVideo = /^(?:open|play) (https:\/\/\S+)$/.exec(command);
    if (directVideo) {
      const url = new URL(directVideo[1]);
      const id = url.hostname === 'youtu.be' ? url.pathname.slice(1)
        : ['www.youtube.com', 'youtube.com', 'm.youtube.com'].includes(url.hostname)
          && url.pathname === '/watch' ? url.searchParams.get('v') : null;
      if (!id || !/^[\w-]{11}$/.test(id)) return 'Enter a YouTube video link or tell me what to search for.';
      if (openRequestedPage('Watch video', 'https://www.youtube.com/watch?v=' + id)) return 'I opened the YouTube video.';
      return 'The YouTube video is ready to open.';
    }
    const search = /^(?:play|find|search for) (.+?) on (?:youtube|you tube)$/i.exec(command);
    if (search) return searchYouTube(search[1]);
    if (/^(?:read|show|give me)(?: my)? (?:today'?s report|daily report|due follow-ups)$/.test(lower)) {
      const report = await request('/api/report');
      launch('Download report', '/api/report');
      const summary = 'You have ' + report.conversations.length + ' conversations logged today and ' + report.due.length + ' follow-ups due.';
      const items = report.due.slice(0, 5).map(item => item.name + ' at ' + time.format(new Date(item.followUpAt)));
      return items.length ? summary + ' Next on the list: ' + items.join('; ') + '.' : summary;
    }
    const note = /^save (?:a )?note for (.+?)(?:\s+saying\s+|:\s*)(.+)$/is.exec(command);
    if (note) {
      const [, name, notes] = note;
      await post('/api/records', { name, notes });
      try { await refresh(); } catch { notice.textContent = 'Saved. Reload to see the updated list.'; }
      return 'I saved your note for ' + name + '.';
    }
    const schedule = /^schedule (?:a )?follow[- ]up for (.+?) (?:on )?(today|tomorrow|\d{4}-\d{2}-\d{2}) (?:at )?(\d{1,2})(?::(\d{2}))?\s*(am|pm)?$/i.exec(command);
    if (schedule) {
      const [, name, day, hour, minute, meridiem] = schedule;
      const when = parseDate(day.toLowerCase(), hour, minute, meridiem?.toLowerCase());
      const record = await findCustomer(name, () => true, 'Save a note for ' + name + ' before scheduling a follow-up.');
      const updated = await post('/api/records/' + record.id + '/schedule', { followUpAt: when });
      launch('Add to Google Calendar', calendarUrl(updated));
      try { await refresh(); } catch { notice.textContent = 'Scheduled. Reload to see the updated list.'; }
      return 'I scheduled your local follow-up with ' + updated.name + ' for ' + time.format(new Date(when)) + ' India time.';
    }
    const whatsapp = /^draft (?:a )?whats\s?app(?: message)? for (.+)$/i.exec(command);
    if (whatsapp) {
      const name = whatsapp[1];
      const customer = await findCustomer(name, item => Boolean(whatsAppUrl(item)), 'No WhatsApp number is saved for ' + name + '.');
      launch('Review WhatsApp draft', whatsAppUrl(customer));
      return 'Your WhatsApp draft for ' + customer.name + ' is ready to review.';
    }
    const calendar = /^open calendar follow[- ]up for (.+)$/i.exec(command);
    if (calendar) {
      const name = calendar[1];
      const customer = await findCustomer(name, item => item.followUpAt && !item.completedAt, 'No pending follow-up is saved for ' + name + '.');
      launch('Add to Google Calendar', calendarUrl(customer));
      return 'Your calendar draft is ready for ' + time.format(new Date(customer.followUpAt)) + ' India time.';
    }
    const help = /^(help|what can you do|show commands)$/.test(lower);
    if (help) return 'Try Open YouTube, Open Gmail, Save note for Rahul saying Interested in a 2BHK, or Read today’s report. Open Voice commands for more.';
    if (/^(?:read|send) (?:my )?(?:latest |unread )?(?:gmail|e-?mail)/i.test(command)) {
      openRequestedPage('Open Gmail', 'https://mail.google.com/');
      return 'This build can open Gmail. Reading and sending email by voice needs a Gmail connection.';
    }
    if (/\b(?:make|generate|render|create)\b.*\bvideo (?:file|from|with)\b/i.test(command)) {
      return 'This build can write a script with local AI. Rendering a video file is not connected here.';
    }
    const answer = await post('/api/ask', { text });
    return answer.reply;
  }

  async function run(text) {
    if (running || !text.trim()) return;
    running = true;
    runButton.disabled = true;
    listenButton.disabled = true;
    actions.replaceChildren();
    response.textContent = '';
    notice.textContent = 'Working on it…';
    try {
      const result = await execute(text.trim());
      if (notice.textContent === 'Working on it…') notice.textContent = '';
      reply(result);
    } catch (error) {
      notice.textContent = 'Could not finish';
      reply(error.message || 'Something went wrong.');
    } finally {
      running = false;
      runButton.disabled = false;
      listenButton.disabled = !Recognition;
    }
  }
  form.addEventListener('submit', event => {
    event.preventDefault();
    void run(input.value);
  });
  stopButton.addEventListener('click', () => speech?.cancel());
  if (Recognition) {
    recognition = new Recognition();
    recognition.lang = 'en-IN';
    recognition.continuous = false;
    recognition.interimResults = false;
    recognition.onstart = () => {
      listening = true;
      listenButton.textContent = 'Stop microphone';
      notice.textContent = 'Listening…';
    };
    recognition.onerror = event => {
      notice.textContent = event.error === 'not-allowed'
        ? 'Allow microphone access in your browser or type the command.'
        : 'Could not hear a command. Try again or type it.';
    };
    recognition.onend = () => {
      listening = false;
      listenButton.textContent = 'Start microphone';
      if (notice.textContent === 'Listening…') notice.textContent = '';
    };
    recognition.onresult = event => {
      const text = event.results[event.resultIndex]?.[0]?.transcript?.trim();
      if (!text) return;
      input.value = text;
      void run(text);
    };
    listenButton.addEventListener('click', () => {
      if (listening) {
        recognition.stop();
        return;
      }
      try {
        speech?.cancel();
        recognition.start();
      } catch {
        notice.textContent = 'The microphone is already starting. Try again in a moment.';
      }
    });
  } else {
    listenButton.disabled = true;
    notice.textContent = 'This browser does not offer speech recognition. Type a command to use J.A.R.V.I.S.';
  }
})();