import http from 'node:http';
import { readFileSync, writeFileSync, renameSync, existsSync } from 'node:fs';
import { randomUUID } from 'node:crypto';

const database = new URL('./business-data.json', import.meta.url);
const temporary = new URL('./business-data.tmp', import.meta.url);
const page = readFileSync(new URL('./index.html', import.meta.url));
const voice = readFileSync(new URL('./voice.js', import.meta.url));
const port = Number(process.env.JARVIS_PORT || 8787);
const origin = 'http://127.0.0.1:' + port;
let records = existsSync(database) ? JSON.parse(readFileSync(database, 'utf8')) : [];
function save(next) {
  writeFileSync(temporary, JSON.stringify(next, null, 2), { mode: 0o600 });
  renameSync(temporary, database);
  records = next;
}
function expire() {
  const cutoff = new Date();
  cutoff.setUTCFullYear(cutoff.getUTCFullYear() - 1);
  const retained = records.filter(record => record.createdAt > cutoff.toISOString());
  if (retained.length !== records.length) save(retained);
}
function send(res, status, data) {
  res.writeHead(status, { 'Content-Type': 'application/json', 'Cache-Control': 'no-store' });
  res.end(JSON.stringify(data));
}
function indiaDay(date) {
  return new Intl.DateTimeFormat('en-CA', {timeZone:'Asia/Kolkata', year:'numeric', month:'2-digit', day:'2-digit'}).format(date);
}
const server = http.createServer(async (req, res) => {
  try {
    if (req.headers.host !== '127.0.0.1:' + port) return send(res,403,{error:'Use the local app URL.'});
    if (req.method === 'POST' && req.headers.origin !== origin) return send(res,403,{error:'Use the local app.'});
    expire();
    const path = new URL(req.url, origin).pathname;
    if (req.method === 'GET' && path === '/') {
      res.writeHead(200, {'Content-Type':'text/html; charset=utf-8','Cache-Control':'no-store'});
      return res.end(page);
    }
    if (req.method === 'GET' && path === '/voice.js') {
      res.writeHead(200, { 'Content-Type': 'text/javascript; charset=utf-8', 'Cache-Control': 'no-store' });
      return res.end(voice);
    }
    if (req.method === 'POST' && path === '/api/ask') {
      const model = process.env.JARVIS_OLLAMA_MODEL?.trim();
      if (!model) return send(res, 503, { error: 'Local AI chat is off. Set JARVIS_OLLAMA_MODEL to enable it, or try one of the built-in commands.' });
      let body = '';
      for await (const chunk of req) {
        body += chunk;
        if (Buffer.byteLength(body) > 24000) return send(res, 413, { error: 'The question is too long.' });
      }
      let text;
      try { text = JSON.parse(body)?.text; } catch { return send(res, 400, { error: 'Invalid question.' }); }
      if (typeof text !== 'string' || !text.trim() || text.length > 4000) return send(res, 400, { error: 'Enter a question up to 4,000 characters.' });
      try {
        const result = await fetch('http://127.0.0.1:11434/api/chat', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            model,
            stream: false,
            options: { num_predict: 400 },
            messages: [
              { role: 'system', content: 'You are JARVIS. Answer clearly and briefly in the user’s language. You are answering a question and have no tools in this mode. Never claim to have performed an external action. For a script request, provide the script in plain text.' },
              { role: 'user', content: text },
            ],
          }),
          signal: AbortSignal.timeout(90000),
        });
        if (!result.ok) return send(res, 502, { error: 'Ollama could not run the configured model. Check that the model is installed.' });
        const reply = (await result.json()).message?.content?.trim();
        if (!reply) return send(res, 502, { error: 'The local model returned an empty reply.' });
        return send(res, 200, { reply });
      } catch (error) {
        const message = error.name === 'TimeoutError' ? 'The local model timed out.' : 'Could not connect to Ollama. Start it and try again.';
        return send(res, 502, { error: message });
      }
    }
    if (req.method === 'GET' && path === '/api/records') return send(res,200,records);
    if (req.method === 'GET' && path === '/api/report') {
      const now = new Date();
      const day = indiaDay(now);
      const conversations = records.filter(r => indiaDay(new Date(r.createdAt)) === day);
      const due = records.filter(r => r.followUpAt && !r.completedAt && indiaDay(new Date(r.followUpAt)) <= day);
      return send(res,200,{day,timeZone:'Asia/Kolkata',conversations,due});
    }
    if (req.method === 'POST' && path === '/api/records') {
      let body = '';
      for await (const chunk of req) {
        body += chunk;
        if (Buffer.byteLength(body) > 128000) return send(res,413,{error:'Record is too large.'});
      }
      let input;
      try { input = JSON.parse(body); } catch { return send(res,400,{error:'Invalid JSON.'}); }
      if (!input || typeof input !== 'object') return send(res,400,{error:'Invalid record.'});
      const name = typeof input.name === 'string' ? input.name.trim() : '';
      const notes = typeof input.notes === 'string' ? input.notes.trim() : '';
      const rawPhone = typeof input.phone === 'string' ? input.phone.trim() : '';
      const phone = rawPhone.replace(/[\s().-]/g, '');
      if (rawPhone && !/^\+[1-9]\d{6,14}$/.test(phone)) {
        return send(res,400,{error:'Enter the WhatsApp number with country code, for example +919876543210.'});
      }
      const followUp = input.followUpAt ? new Date(input.followUpAt) : null;
      if (!name || name.length > 200 || !notes || notes.length > 20000 || (followUp && !Number.isFinite(+followUp))) return send(res,400,{error:'Enter a customer, notes, and a valid follow-up time.'});
      const record = { id: randomUUID(), name, notes, phone: phone || null, followUpAt: followUp?.toISOString() ?? null, createdAt:new Date().toISOString(), completedAt:null };
      save([record, ...records]);
      return send(res,201,record);
    }
    const schedule = /^\/api\/records\/([a-f0-9-]+)\/schedule$/.exec(path);
    if (req.method === 'POST' && schedule) {
      let body = '';
      for await (const chunk of req) {
        body += chunk;
        if (Buffer.byteLength(body) > 4096) return send(res,413,{error:'Request is too large.'});
      }
      let followUpAt;
      try { followUpAt = JSON.parse(body)?.followUpAt; } catch { return send(res,400,{error:'Invalid follow-up date.'}); }
      const date = typeof followUpAt === 'string' ? new Date(followUpAt) : null;
      if (!date || !Number.isFinite(+date) || +date <= Date.now()) return send(res,400,{error:'Enter a valid future follow-up time.'});
      const currentIndex = records.findIndex(r => r.id === schedule[1]);
      if (currentIndex < 0) return send(res,404,{error:'Record not found.'});
      const next = [...records];
      next[currentIndex] = { ...next[currentIndex], followUpAt: date.toISOString(), completedAt: null };
      save(next);
      return send(res,200,next[currentIndex]);
    }
    const close = /^\/api\/records\/([a-f0-9-]+)\/complete$/.exec(path);
    if (req.method === 'POST' && close) {
      const index = records.findIndex(r => r.id === close[1]);
      if (index < 0) return send(res,404,{error:'Record not found.'});
      if (!records[index].completedAt) {
        const next = [...records];
        next[index] = { ...next[index], completedAt:new Date().toISOString() };
        save(next);
      }
      return send(res,200,records[index]);
    }
    return send(res,404,{error:'Page not found.'});
  } catch (error) {
    console.error(error);
    return send(res,500,{error:'Could not read or save business records.'});
  }
});
server.listen(port,'127.0.0.1',() => console.log('J.A.R.V.I.S. Business Desk: ' + origin));
setInterval(() => { try { expire(); } catch (error) { console.error(error); } }, 3600000).unref();
