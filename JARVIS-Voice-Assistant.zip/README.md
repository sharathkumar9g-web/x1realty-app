# J.A.R.V.I.S. Voice Assistant

This Windows build runs locally and includes the Business Desk. Give supported commands by voice or text, hear the reply, and see the result. The microphone is push-to-talk.

## Start on Windows

1. Extract the ZIP and open PowerShell in the extracted folder.
2. With Node.js 22 or newer installed, run node server.mjs.
3. Open http://127.0.0.1:8787 in your browser.
4. Choose Start microphone and allow microphone access, or type a command. Keep PowerShell open while using the app.

Browser speech recognition depends on the browser and can use an online speech service. Typed commands remain available without speech recognition.

## Try these commands

- Open YouTube
- Play BGMI highlights on YouTube
- Open Gmail
- Save note for Rahul saying Interested in a 2BHK
- Schedule follow-up for Rahul tomorrow at 5 PM
- Read today's report
- Draft WhatsApp for Rahul, after saving his number in the customer form
- Open calendar follow-up for Rahul

Follow-ups are stored locally in India time. Save the Calendar draft separately to create a Google Calendar event. WhatsApp opens a draft for you to send. YouTube opens matching search results for spoken titles and can open a direct video link. If the browser blocks popups, click the displayed link.

## Enable local AI questions and script writing

Install Ollama and download a local model. For example, run:

    ollama pull qwen2.5:1.5b
    $env:JARVIS_OLLAMA_MODEL = 'qwen2.5:1.5b'
    node server.mjs

Keep Ollama running on its default local port. Start Node in the same PowerShell session where you set the variable. Use the name of any supported local model you installed. The app sends general questions and script requests to the local Ollama process. Built-in business commands run even with the model turned off.

## Customer records

Business Desk stores records in business-data.json beside server.mjs and expires records one calendar year after creation. Keep the file private. To bring records from Business Desk v2, stop both versions and copy business-data.json into the new folder. The daily JSON report is available on demand.

This build supports one configurable local model at a time. It runs separately from the original Tactical HUD. Hands-free wake-word listening, phone calls and recording, automatic callbacks, Gmail inbox reading, video rendering, Gmail or Drive delivery, and 25-agent orchestration remain pending.